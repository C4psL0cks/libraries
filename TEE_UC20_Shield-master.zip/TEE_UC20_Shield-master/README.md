# TEE_UC20_Shield
Libraly and Example code Quectel UC20 3G Shield for Arduino Board.

Doucument
- 3G_Shield_User_Manual(TH) (https://github.com/ThaiEasyElec/TEE_UC20_Shield/blob/master/3G%20Shield%20manual/ETEE059_3G_Shield_User_Manual_TH_20160321.pdf)
- Development_Guide_for_3G_Shield(TH) (https://github.com/ThaiEasyElec/TEE_UC20_Shield/blob/master/3G%20Shield%20manual/Development_Guide_for_3G_Shield_and_3G_Module_using_Arduino_TH_20160726.pdf)

Application Note!
must be add AltSoftSerial Library
- https://github.com/PaulStoffregen/AltSoftSerial


![uc20](https://user-images.githubusercontent.com/8803501/61520567-b1d61a80-aa38-11e9-8c57-76e7863852f1.PNG)


